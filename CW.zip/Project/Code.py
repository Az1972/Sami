import pandas as pd
import matplotlib.pyplot as plt
from typing import List, Dict
import json
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MP:
    def __init__(self, first_name: str, surname: str, party: str, votes: int, share: float, gender: str):
        self.first_name = first_name
        self.surname = surname
        self.party = party
        self.votes = votes
        self.share = share
        self.gender = gender
        
    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.surname}"
    
    def to_dict(self) -> dict:
        return {
            "first_name": self.first_name,
            "surname": self.surname,
            "party": self.party,
            "votes": self.votes,
            "share": self.share,
            "gender": self.gender
        }

class Party:
    def __init__(self, name: str):
        self.name = name
        self.mps: List[MP] = []
        
    def add_mp(self, mp: MP) -> None:
        self.mps.append(mp)
        
    @property
    def total_votes(self) -> int:
        return sum(mp.votes for mp in self.mps)
    
    @property
    def gender_distribution(self) -> Dict[str, int]:
        distribution = {"M": 0, "F": 0, "Unknown": 0}
        for mp in self.mps:
            distribution[mp.gender] += 1
        return distribution
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "total_votes": self.total_votes,
            "mp_count": len(self.mps),
            "gender_distribution": self.gender_distribution
        }

class Constituency:
    def __init__(self, name: str, country: str):
        self.name = name
        self.country = country
        self.candidates: List[MP] = []
        
    def add_candidate(self, candidate: MP) -> None:
        self.candidates.append(candidate)
        
    @property
    def winner(self) -> MP:
        return max(self.candidates, key=lambda x: x.votes)
    
    @property
    def total_votes(self) -> int:
        return sum(candidate.votes for candidate in self.candidates)
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "country": self.country,
            "total_votes": self.total_votes,
            "winner": self.winner.full_name,
            "winning_party": self.winner.party
        }

class ElectionAnalyzer:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.constituencies: Dict[str, Constituency] = {}
        self.parties: Dict[str, Party] = {}
        self.load_data()

    def load_data(self) -> None:
        try:
            df = pd.read_csv(self.file_path)
            df["Candidate gender"] = df["Candidate gender"].map({"Male": "M", "Female": "F"}).fillna("Unknown")
            
            for _, row in df.iterrows():
                mp = MP(
                    first_name=row["Candidate first name"],
                    surname=row["Candidate surname"],
                    party=row["Party name"],
                    votes=row["Votes"],
                    share=row["Share"],
                    gender=row["Candidate gender"]
                )
                
                const_name = row["Constituency name"]
                if const_name not in self.constituencies:
                    self.constituencies[const_name] = Constituency(const_name, row["Country name"])
                self.constituencies[const_name].add_candidate(mp)
                
                if mp.party not in self.parties:
                    self.parties[mp.party] = Party(mp.party)
                self.parties[mp.party].add_mp(mp)
        except Exception as e:
            logger.error(f"Error loading data: {str(e)}")
            raise

    def save_statistics(self, filename: str = "election_statistics.json") -> None:
        try:
            nation_stats = {
                nation: {
                    "total_votes": sum(const.total_votes for const in self.constituencies.values() if const.country == nation),
                    "constituency_count": sum(1 for const in self.constituencies.values() if const.country == nation)
                }
                for nation in set(const.country for const in self.constituencies.values())
            }

            stats = {
                "parties": {name: party.to_dict() for name, party in self.parties.items()},
                "constituencies": {name: const.to_dict() for name, const in self.constituencies.items()},
                "nation_statistics": nation_stats,
            }

            with open(filename, 'w') as f:
                json.dump(stats, f, indent=4)
            logger.info(f"Statistics saved to {filename}")
        except Exception as e:
            logger.error(f"Error saving statistics: {str(e)}")

    def nation_statistics(self) -> None:
        try:
            nation_stats = {}
            for const in self.constituencies.values():
                nation = const.country
                if nation not in nation_stats:
                    nation_stats[nation] = {"total_votes": 0, "constituencies": 0}
                nation_stats[nation]["total_votes"] += const.total_votes
                nation_stats[nation]["constituencies"] += 1

            print("\n--- Nation Statistics ---")
            for nation, stats in nation_stats.items():
                avg_votes = stats["total_votes"] / stats["constituencies"]
                print(f"{nation}:")
                print(f"  Total Votes: {stats['total_votes']}")
                print(f"  Average Votes per Constituency: {avg_votes:.1f}")
        except Exception as e:
            logger.error(f"Error computing nation statistics: {str(e)}")

    def plot_party_votes(self) -> None:
        try:
            parties = sorted(self.parties.items(), key=lambda x: x[1].total_votes, reverse=True)[:10]
            names = [p[0] for p in parties]
            votes = [p[1].total_votes for p in parties]
            
            plt.figure(figsize=(12, 6))
            plt.bar(names, votes)
            plt.xticks(rotation=45, ha='right')
            plt.title('Top 10 Parties by Total Votes')
            plt.ylabel('Total Votes')
            plt.tight_layout()
            plt.show()
        except Exception as e:
            logger.error(f"Error plotting party votes: {str(e)}")

    def plot_gender_distribution(self) -> None:
        try:
            party_names = []
            female_percentages = []
            
            for party_name, party in sorted(self.parties.items(), 
                                          key=lambda x: len(x[1].mps), 
                                          reverse=True)[:10]:
                if len(party.mps) >= 5:
                    dist = party.gender_distribution
                    total = dist['M'] + dist['F']
                    if total > 0:
                        party_names.append(party_name)
                        female_percentages.append((dist['F'] / total) * 100)
            
            plt.figure(figsize=(12, 6))
            plt.bar(party_names, female_percentages)
            plt.xticks(rotation=45, ha='right')
            plt.title('Female MP Percentage by Party')
            plt.ylabel('Percentage of Female MPs')
            plt.axhline(y=50, color='r', linestyle='--', label='50% mark')
            plt.legend()
            plt.tight_layout()
            plt.show()
        except Exception as e:
            logger.error(f"Error plotting gender distribution: {str(e)}")

def enhanced_voting_analysis_menu():
    try:
        analyzer = ElectionAnalyzer("HoC-GE2024-results-by-candidate.csv")
    except Exception as e:
        print(f"Error initializing analyzer: {str(e)}")
        return

    while True:
        print("\n=== Enhanced Voting Analysis Menu ===")
        print("1. Display available columns")
        print("2. Search by Candidate Name")
        print("3. Search by Party Name")
        print("4. Search by Constituency Name")
        print("5. Show Total Votes Cast in a Constituency")
        print("6. Show Party Statistics")
        print("7. Show Nation Statistics")
        print("8. Plot Party Vote Distribution")
        print("9. Plot Gender Distribution")
        print("10. Save Statistics to File")
        print("11. Exit")
        
        try:
            choice = input("Enter your choice: ").strip()
            
            if choice == "1":
                print("\n--- Available Columns ---")
                df = pd.read_csv(analyzer.file_path)
                print(", ".join(df.columns))

            elif choice == "2":
                name = input("Enter Candidate's Name: ").strip().lower()
                found = False
                for constituency in analyzer.constituencies.values():
                    for candidate in constituency.candidates:
                        if name in candidate.full_name.lower():
                            print(f"\nName: {candidate.full_name}")
                            print(f"Party: {candidate.party}")
                            print(f"Votes: {candidate.votes}")
                            print(f"Share: {candidate.share}%")
                            found = True
                if not found:
                    print("Candidate not found.")

            elif choice == "3":
                party_name = input("Enter Party Name: ").strip()
                if party_name in analyzer.parties:
                    party = analyzer.parties[party_name]
                    print(f"\nParty: {party.name}")
                    print(f"Total Votes: {party.total_votes}")
                    print(f"MP Count: {len(party.mps)}")
                    print(f"Gender Distribution: {party.gender_distribution}")
                else:
                    print("Party not found.")

            elif choice == "4":
                const_name = input("Enter Constituency Name: ").strip()
                if const_name in analyzer.constituencies:
                    constituency = analyzer.constituencies[const_name]
                    print(f"\nConstituency: {constituency.name}")
                    print(f"Country: {constituency.country}")
                    print(f"Winner: {constituency.winner.full_name} ({constituency.winner.party})")
                    print(f"Total Votes: {constituency.total_votes}")
                else:
                    print("Constituency not found.")

            elif choice == "5":
                const_name = input("Enter Constituency Name: ").strip()
                if const_name in analyzer.constituencies:
                    total_votes = analyzer.constituencies[const_name].total_votes
                    print(f"\nTotal Votes Cast in {const_name}: {total_votes}")
                else:
                    print("Constituency not found.")

            elif choice == "6":
                print("\n--- Party Statistics ---")
                for party in sorted(analyzer.parties.values(), key=lambda x: x.total_votes, reverse=True):
                    print(f"{party.name}: {party.total_votes} votes ({len(party.mps)} MPs)")

            elif choice == "7":
                analyzer.nation_statistics()

            elif choice == "8":
                analyzer.plot_party_votes()

            elif choice == "9":
                analyzer.plot_gender_distribution()

            elif choice == "10":
                analyzer.save_statistics()

            elif choice == "11":
                print("Exiting.")
                break

            else:
                print("Invalid choice. Please try again.")
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            logger.error(f"Error in menu operation: {str(e)}")

if __name__ == "__main__":
    enhanced_voting_analysis_menu()